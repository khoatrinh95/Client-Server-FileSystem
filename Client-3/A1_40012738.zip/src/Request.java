import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.channels.UnresolvedAddressException;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public abstract class Request {
    protected String url;
    protected String host;
    protected String path;
    protected String query;
    protected String userAgent;
    protected String contentType;
    protected int port;
    protected boolean isVerbose;
    protected boolean isInputValid = true;
    protected InetSocketAddress socketAddress;
    protected SocketChannel socketChannel;

    private static final String HOST = "Host";
    private static final String CONTENT_TYPE = "Content-Type";
    private static final String CONTENT_LENGTH = "Content-Length";
    private static final String USER_AGENT = "User-Agent";

    public Request(String url, String option) {
        this.url = url;
        URI uri = null;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e){
            System.out.println(e.getMessage());
        }

        this.host = uri.getHost();
        this.path = uri.getPath();
        if (path == null || path.length() == 0) {
            path = "/";
        }


        this.query = uri.getQuery();
        if (query != null) {
            query = "?" + query;
        }

        this.port = uri.getPort();
        if (port == -1) {
            port = 80;
        }

        if (option.contains("-v ")){
            isVerbose = true;
        }
        socketAddress = new InetSocketAddress(host, port);
    }


    private boolean connectSocket() {
        try {
            // open channel
            socketChannel = SocketChannel.open();

            // connect socket to channel
            socketChannel.connect(socketAddress);
            System.out.println("Connection with host established ...");
            return true;
        } catch (Exception e) {
            System.out.println("Cannot establish connection with host");
        }
        return false;
    }

    private String writeAndRead(String request){
        String response = null;
        try {
            // writing the request to buffer
            Charset charSetUTF8 = StandardCharsets.UTF_8;
            ByteBuffer buffer = charSetUTF8.encode(request);
            socketChannel.write(buffer);

            // reading response from buffer
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            buffer = ByteBuffer.allocateDirect(32768);
            WritableByteChannel byteChannel = Channels.newChannel(outputStream);
            if (socketChannel.read(buffer) != -1) {
                buffer.flip();
                byteChannel.write(buffer);
                buffer.clear();
                response = new String(outputStream.toByteArray(), "UTF-8");
            }
        } catch (Exception e) {
            System.out.println("Cannot communicate with host");
        }
        return response;
    }

    private String packResponse(String response) {
        return (isVerbose? response: response.substring(response.indexOf("{"), response.lastIndexOf("}") + 1));
    }

    public String packRequest() {
        return "GET " + path + query + " HTTP/1.0\r\n" + "Host: " + host + "\r\n" + "Connection: close\r\n" + "User-Agent: " + userAgent + "\r\n" + "\r\n";
    }

    public String send() {
        connectSocket();

        String request = packRequest();
        String response = writeAndRead(request);

        return (isInputValid? packResponse(response) : "Your input is not valid");

    }
    public static String help(){
        return "httpc help \n\n" +
                "httpc is a curl-like application but supports HTTP protocol only. \n" +
                "Usage: \n" +
                "\thttpc command [arguments]\n" +
                "The commands are: \n" +
                "\tget\t\t executes a HTTP GET request and prints the response.\n" +
                "\tpost\t executes a HTTP POST request and prints the response.\n" +
                "\thelp\t prints this screen.\n\n" +
                "Use \"httpc help [command]\" for more information about a command.\n";
    }

    public static String helpGet(){
        return "httpc help get\n\n" +
                "usage: httpc get [-v] [-h key:value] URL \n\n" +
                "Get executes a HTTP GET request for a given URL. \n" +
                "\t-v\t\t\t\t Prints the detail of the response such as protocol, status, and headers.\n" +
                "\t-h hey:value\t Associates headers to HTTP Request with the format 'key:value'.\n";
    }

    public static String helpPost(){
        return "httpc help post\n\n" +
                "usage: httpc post [-v] [-h key:value] [-d inline-data] [-f file] URL \n\n" +
                "Post executes a HTTP POST request for a given URL with inline data or from file.\n" +
                "\t-v\t\t\t\t Prints the detail of the response such as protocol, status, and headers.\n" +
                "\t-h hey:value\t Associates headers to HTTP Request with the format 'key:value'.\n" +
                "\td string\t\t Associates an inline data to the body HTTP POST request.\n" +
                "\t-f file\t\t\t Associates the content of a file to the body HTTP POST request.\n\n" +
                "Either [-d] or [-f] can be used but not both.";
    }

    public static String invalidInput(){
        return "Invalid input\n\n" +
                "Use 'httpc help' for instructions \n\n";
    }
}
