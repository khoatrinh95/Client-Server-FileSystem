import Exceptions.ForbiddenAccessException;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Server {
    private int port;
    private String host;
    private boolean isVerbose;
    private String pathToDir;
    private ServerSocket serverSocket;
    private Socket clientSocket;

    // response attributes
    private ArrayList<String> request= new ArrayList<>();
    private String responseStatus = null;
    private String responseContent = null;
    private FileTime lastModified = null;


    private static final String FILE_NOT_FOUND = "HTTP/1.0 404 Not Found";
    private static final String BAD_REQUEST = "HTTP/1.0 400 Bad Request";
    private static final String FORBIDDEN = "HTTP/1.0 403 Forbidden";
    private static final String OK = "HTTP/1.0 200 OK";
    private static final String SERVER_ERROR = "HTTP/1.0 500 Internal Server Error";

    public Server(int port, String host, boolean isVerbose, String pathToDir) {
        System.out.println("Starting server on: ");
        System.out.println("Host: " + host);
        System.out.println("Port: " + port);
        System.out.println("Verbose: " + isVerbose);
        System.out.println("Path: " + pathToDir);
        System.out.println();

        this.port = port;
        this.host = host;
        this.isVerbose = isVerbose;
        this.pathToDir = pathToDir.substring(1);

        // start server
        startServer();
    }

    private void startServer() {
        connectSocket();
    }

    private boolean connectSocket() {
        try {
            serverSocket = new ServerSocket(this.port);
            System.out.println("Server started ...\n");
            // wait for connection
            while (true) {
                // accept a client
                clientSocket = serverSocket.accept();

                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));

                String s;
                while ((s = in.readLine()) != null) {
                    request.add(s);
                    if (s.isEmpty()) {
                        break;
                    }
                }

                // check if request is get or post
                if (request.get(0).contains("GET")){
                    responseContent = processGetRequest(request);
                } else if (request.get(0).contains("POST")) {
                    responseContent = processPostRequest(request);
                }

                // parse response and write to output stream
                out.write(parseResponse());
                printDebuggingMessage();

                // Close streams
                out.close();
                in.close();
                clientSocket.close();
                clearResponse();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Cannot establish server connection");
        }
        return false;
    }

    private String processGetRequest(ArrayList<String> request) {
        String firstLine = request.get(0);
        String[] firstLineSplit = firstLine.split(" ");
        String path = firstLineSplit[1];
        String result = "";

        // if path = / -> get list
        if (path.equalsIgnoreCase("/")){
            result = getListOfFiles(path);
        }
        // else -> read file (throw exc if filenotfound)
        else {
            result = readFile(path);
        }
        return result;
    }

    private String processPostRequest(ArrayList<String> request) {
        String firstLine = request.get(0);
        String[] firstLineSplit = firstLine.split(" ");
        String path = firstLineSplit[1];

        ArrayList<String> toBeWritten = new ArrayList<>();
        boolean startAdding = false;
        for (String s : request) {
            if (startAdding){
                toBeWritten.add(s);
            }
            if (s.equalsIgnoreCase(" ")){
                startAdding = true;
            }
        }

        writeToFile(path, toBeWritten);

        return readFile(path);
    }

    private String getListOfFiles (String path) {
        File folder = new File(pathToDir + "/" + path);
        File[] listOfFiles = folder.listFiles();

        String stringListOfFiles = "";
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                stringListOfFiles += (listOfFiles[i].getName());
            } else if (listOfFiles[i].isDirectory()) {
                stringListOfFiles += ("/" + listOfFiles[i].getName());
            }
            if (i!= listOfFiles.length){
                stringListOfFiles += "\n";
            }
        }
        responseStatus = OK;
        return stringListOfFiles;
    }

    private String readFile (String path) {
        String content = "";
        try {
            // security access: check if path provided is inside pathToDir
            // if not -> throw ForbiddenAccessException
            File fileTestSecurity = new File(pathToDir + "/" + path);
            if (path.contains("..") || !fileTestSecurity.getParent().substring(0,pathToDir.length()).equalsIgnoreCase(pathToDir)) {
                throw new ForbiddenAccessException();
            }

            // security access: pathToDir + "/" + path
            // this will not allow client to go outside of /pathToDir
            BufferedReader br = new BufferedReader(new FileReader(pathToDir + "/" + path));
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }
            content = sb.toString();
            responseStatus = OK;

            // get file attribute
            Path file = Paths.get(pathToDir + "/" + path);
            BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);
            lastModified = attr.lastModifiedTime();

            br.close();
        } catch (FileNotFoundException e) {
            responseStatus = FILE_NOT_FOUND;
//            printDebuggingMessage(responseStatus);
        } catch (IOException e) {
            responseStatus = SERVER_ERROR;
//            printDebuggingMessage(responseStatus);
        } catch (ForbiddenAccessException e) {
            responseStatus = FORBIDDEN;
//            printDebuggingMessage(responseStatus);
        }
        return content;
    }

    private String parseResponse () {
        String response = "";

        // get current time
        ZonedDateTime now = ZonedDateTime.now();

        // get expired time
        ZonedDateTime nextDay = ZonedDateTime.now().plusDays(1);

        DateTimeFormatter formatter = DateTimeFormatter.RFC_1123_DATE_TIME;
        String timeNow = now.format(formatter);
        String timeNextDay = nextDay.format(formatter);

        response += (responseStatus + "\r\n");
        response += ("Date: " + timeNow +"\r\n");
        response += ("Server: Apache/0.8.4\r\n");
        response += ("Content-Type: text\r\n");
        response += ("Content-Length: " + responseContent.length() + "\r\n");
        response += ("Expires: " + timeNextDay +"\r\n");

        if (lastModified != null) {
            long cTime = lastModified.toMillis();
            ZonedDateTime temp = Instant.ofEpochMilli(cTime).atZone(ZoneId.of("UTC-4"));
            String timeFileLastModified = temp.format(formatter);
            response += ("Last-modified: " + timeFileLastModified + "\r\n");
        }

        response += ("\r\n");
        response += (responseContent);
        return response;
    }

    private String writeToFile(String path, ArrayList<String> toBeWritten) {
        try {
            FileWriter fw = new FileWriter(pathToDir + "/" + path);

            for (String s : toBeWritten) {
                fw.write(s);
                fw.write("\n");
            }
            responseStatus = OK;
            fw.close();
        } catch (IOException e) {
            responseStatus = SERVER_ERROR;
//            printDebuggingMessage(responseStatus);
        }
        return null;
    }

    private void clearResponse() {
        request.clear();
        responseStatus = "";
        responseContent = "";
        lastModified = null;
    }

    private void printDebuggingMessage(){
        if (isVerbose) {
            System.err.println("Receiving request from Client: ");
            System.err.println("Port: " + clientSocket.getPort());
            System.err.println("Address: " + clientSocket.getInetAddress());
            for (String s : request) {
                System.err.println(s);
            }
            System.err.println("STATUS: " + responseStatus);
        }
    }
}
